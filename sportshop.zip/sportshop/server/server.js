import express from "express";
import cors from "cors";
import OpenAI from "openai";

const app = express();
const PORT = 3000;

const client = new OpenAI({
  baseURL: "http://localhost:11434/v1",
  apiKey: "ollama"
});

app.use(cors());
app.use(express.json({ limit: "1mb" }));

function buildSystemPrompt(context = {}) {
  const page = context.page || "unknown";
  const title = context.title || "";
  const product = context.product || null;

  let productContext = "";

  if (product && (product.title || product.category || product.price)) {
    productContext = `
Сейчас пользователь находится на странице товара.
Название товара: ${product.title || "неизвестно"}
Категория: ${product.category || "неизвестно"}
Цена: ${product.price || "неизвестно"}
`;
  }

  return `
Ты — AI-консультант интернет-магазина SportShop.

Правила:
- Отвечай только на русском языке.
- Отвечай понятно и по делу.
- Помогай с подбором спортпита.
- Не выдумывай наличие товара, если данных нет.
- Не выдумывай цену, состав и скидки, если данных нет.
- Если вопрос медицинский или рискованный, не ставь диагнозы и советуй консультацию со специалистом.

НЕ выдумывай названия товаров.
Если не знаешь конкретный товар — говори обобщенно.
Отвечай кратко и по делу.
Отвечай как консультант современного магазина спортпита.

Контекст страницы:
Текущая страница: ${page}
Заголовок страницы: ${title}
${productContext}
`;
}

app.post("/api/chat", async (req, res) => {
  try {
    const { message, history = [], context = {} } = req.body;

    if (!message || typeof message !== "string" || !message.trim()) {
      return res.status(400).json({ reply: "Сообщение пустое." });
    }

    const safeHistory = Array.isArray(history)
      ? history
          .slice(-10)
          .filter(item => item && typeof item.content === "string" && typeof item.role === "string")
          .map(item => ({
            role: item.role === "assistant" ? "assistant" : "user",
            content: item.content.slice(0, 3000)
          }))
      : [];

    const input = [
      {
        role: "system",
        content: buildSystemPrompt(context)
      },
      ...safeHistory,
      {
        role: "user",
        content: message.trim()
      }
    ];

    const response = await client.responses.create({
      model:  "qwen2.5:0.5b",
      input
    });

    const reply =
      response.output_text?.trim() ||
      "Не удалось получить ответ от локальной модели.";

    res.json({ reply });
  } catch (error) {
    console.error("OLLAMA ERROR:", error);
    res.status(500).json({
      reply: "Ошибка локального AI. Проверь, запущен ли Ollama и скачана ли модель."
    });
  }
});

app.listen(PORT, () => {
  console.log(`AI server started: http://localhost:${PORT}`);
});